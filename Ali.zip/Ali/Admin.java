/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackoverflow;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author atiya
 */
public class Admin extends User {

    protected adminDELETE adelq = new adminDELETE();
    protected adminDelJob adelj = new adminDelJob();

    Admin() {
    }

    @Override
    public int checkLogin(String email, String pass) {
        // 11->text field is empty
        // 21->email is invalid
        // 41->email or password is incorrect 
        // 5->exception not handeled
        // 0->admin successful login

        if (email.equals("") || pass.equals("")) {
            //JOptionPane.showMessageDialog(this, " No feild can be empty  ", "Soething went wrong", HEIGHT);
            return 1;
        }

        if (!email.contains("@")) {
            if (!email.endsWith(".com")) {
                //JOptionPane.showMessageDialog(this, " Invalid Email  ", "Soething went wrong", HEIGHT);
                //this.PasswordField.setText("");
                return 2;
            }
            //JOptionPane.showMessageDialog(this, " Invalid Email  ", "Soething went wrong", HEIGHT);
            //this.PasswordField.setText("");
            return 2;
        }

        Connection conn;
        Statement st;
        ResultSet rs;
        int flag = 0;

        try {

            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            st = conn.createStatement();

            //if (emial is of user) go to user table and copmare the password
            rs = st.executeQuery("SELECT * FROM ATIYA.TBL_ADMIN");
            flag = 0;

            //if(email is of admin) go to admin table and copmare the password
            while (rs.next()) {
                if ((email == null ? rs.getString(1) == null : email.equals(rs.getString(1))) && (pass == null ? rs.getString(2) == null : pass.equals(rs.getString(2)))) {
                    System.out.println("ADMIN LOGIN");

                    //=====user_login table======//
                    String query1 = "delete from ATIYA.LOGIN_USER ";
                    PreparedStatement preparedStmt = conn.prepareStatement(query1);
                    preparedStmt.executeUpdate();

                    String query = "INSERT INTO LOGIN_USER(Email)" + "VALUES (?)";
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.setString(1, email);
                    pst.execute();
                    //=====user_login table======//

                    return 0;

                } else {
                    System.out.println("admin email or password is incorrect");
                    flag = 1;
                    //JOptionPane.showMessageDialog(this, " Email or password is incorrect. ", "Soething went wrong", HEIGHT);
                    return 4;
                }

            }

            conn.close();

        } catch (SQLException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);

        }
        return 5;

    }

    @Override
    public void deletePost(String s) {
        adelq.FinalDeletePost(s);
        System.out.println("admin delete");
    }
    
    @Override
    public void deleteJob(String s) {
        adelj.FinalDeleteJob(s);
        System.out.println("admin delete");
    }

}
