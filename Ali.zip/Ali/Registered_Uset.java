/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackoverflow;

import java.awt.Dimension;
import java.awt.List;
import java.awt.Toolkit;
import static java.awt.image.ImageObserver.HEIGHT;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author atiya
 */
public class Registered_Uset extends User {

    protected regUserDELETE rdelq = new regUserDELETE();//association
    protected regUserDelJob rdelj = new regUserDelJob();//association

    Registered_Uset() {

    }

    void add() {

    }

    @Override
    public int checkLogin(String email, String pass) {
        // 1->text field is empty
        // 2->email is invalid
        // 3->user is blocked
        // 4->email or password is incorrect 
        // 5->exception not handeled
        // -1 ->user successful login
        // 0->admin successful login

//        User obj = new Admin();
//        if (obj.checkLogin(email, pass)==0) {
//            return 0;
//        } else 
        {
            if (email.equals("") || pass.equals("")) {
                //JOptionPane.showMessageDialog(this, " No feild can be empty  ", "Soething went wrong", HEIGHT);
                return 1;
            }

            if (!email.contains("@")) {
                if (!email.endsWith(".com")) {
                    //JOptionPane.showMessageDialog(this, " Invalid Email  ", "Soething went wrong", HEIGHT);
                    //this.PasswordField.setText("");
                    return 2;
                }
                //JOptionPane.showMessageDialog(this, " Invalid Email  ", "Soething went wrong", HEIGHT);
                //this.PasswordField.setText("");
                return 2;
            }
            Connection conn;
            Statement st;
            ResultSet rs;
            int flag = 0;
            try {

                conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
                st = conn.createStatement();

                //if (emial is of user) go to user table and copmare the password
                rs = st.executeQuery("SELECT u_email,u_pass, u_status FROM ATIYA.TBL_USER");
                while (rs.next()) {
                    if (rs.getString(1).equals(email) && rs.getString(2).equals(pass)) {
                        if (rs.getString(3).equalsIgnoreCase("blocked")) {
                            return 3;
                        }
                        System.out.println("user login");
                        flag = 0;
                        //=====user_login table======//
                        String query1 = "delete from ATIYA.LOGIN_USER ";
                        PreparedStatement preparedStmt = conn.prepareStatement(query1);
                        preparedStmt.executeUpdate();

                        String query = "INSERT INTO LOGIN_USER(Email)" + "VALUES (?)";
                        PreparedStatement pst = conn.prepareStatement(query);
                        pst.setString(1, email);
                        pst.execute();
                        //=====user_login table======//
                        return -1;
                    } else {
                        flag = 1;   //does not match                 
                    }
                }
                if (flag == 1) {
                    System.out.println("user email or password is incorrect");
                    return 4;
                }

                conn.close();

            } catch (SQLException ex) {
                Logger.getLogger(Registered_Uset.class.getName()).log(Level.SEVERE, null, ex);

            }
        }

        return 5;
    }

    @Override
    public void deletePost(String s) {
        rdelq.FinalDeletePost(s);
        System.out.println("user delete");
    }
    
    @Override
    public void deleteJob(String s) {
        rdelj.FinalDeleteJob(s);
        System.out.println("user delete");
    }

}
