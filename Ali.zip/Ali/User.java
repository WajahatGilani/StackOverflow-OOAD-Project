/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackoverflow;

import java.awt.Dimension;
import java.awt.List;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.*;

/**
 *
 * @author atiya
 */
public class User {

    User() {
    }

    public String getLoginEmail() {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            Statement st = conn.createStatement();
            ResultSet rs;
            String query = "SELECT * FROM ATIYA.LOGIN_USER";

            String loginEmail = "";

            rs = st.executeQuery(query);
            //get the login email
            while (rs.next()) {
                loginEmail = rs.getString(1);
                break;
            }
            conn.close();
            return loginEmail;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public int checkLogin(String email, String pass) {
        if (email.equals("") || pass.equals("")) {
            //JOptionPane.showMessageDialog(this, " No feild can be empty  ", "Soething went wrong", HEIGHT);
            return 1;
        }

        if (!email.contains("@")) {
            if (!email.endsWith(".com")) {
                //JOptionPane.showMessageDialog(this, " Invalid Email  ", "Soething went wrong", HEIGHT);
                //this.PasswordField.setText("");
                return 2;
            }
            //JOptionPane.showMessageDialog(this, " Invalid Email  ", "Soething went wrong", HEIGHT);
            //this.PasswordField.setText("");
            return 2;
        }
        return 100;
    }

    public boolean isAdmin(String email) {

        try {
            //if email is of user return false
            //if email is of admin return true oh nice
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");

            Statement st = conn.createStatement();
            ResultSet rs;

            rs = st.executeQuery("SELECT a_email FROM ATIYA.TBL_ADMIN");

            //if(email is of admin) go to admin table 
            while (rs.next()) {
                if (email.equals(rs.getString(1))) {
                    System.out.println("ADMIN email");
                    return true;

                } else {
                    return false;
                }

            }

            conn.close();

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean isUser(String email) {

        try {
            Connection conn;
            String query = "SELECT u_email FROM ATIYA.TBL_USER";
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            Statement st = conn.createStatement();
            ResultSet rs;
            //if (emial is of user) go to user table and copmare the password
            //assert (st!=null);
            //rs = true ? st.executeQuery(query) :  System.out.println("Problem is here");
            rs = st.executeQuery(query);
            while (rs.next()) {
                if (rs.getString(1).equals(email)) {

                    System.out.println("user email");
                    return true;
                }

            }
            conn.close();
            return false;
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean postQuestion(String title, String body, String tag) {
        try {
            if (body.equals("")) {
                body = "";
            }
            if (tag.equals("")) {
                tag = "";
            }
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");

            Statement st = conn.createStatement();
            ResultSet rs;
            String email = "";
            rs = st.executeQuery("SELECT * FROM ATIYA.LOGIN_USER");
            while (rs.next()) {
                email = rs.getString(1);
                break;
            }

            String query = "INSERT INTO ATIYA.TBL_ASKQUESTION(title,email,body,tag)" + "VALUES (?,?,?,?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, title);
            pst.setString(2, email);
            pst.setString(3, body);
            pst.setString(4, tag);
            pst.execute();
            conn.close();
            return true;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;

    }
    
    public boolean postJob(String title, String company, String description, String country){
        try {
            if (description.equals("")) {
                description = "";
            }
            if (country.equals("")) {
                country = "";
            }
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");

            Statement st = conn.createStatement();
            ResultSet rs;
            String email =this.getLoginEmail();
            

            String query = "INSERT INTO ATIYA.TBL_POSTJOB(jtitle,jcompany,jdescription,jcountry,email)" + "VALUES (?,?,?,?,?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, title);
            pst.setString(2, company);
            pst.setString(3, description);
            pst.setString(4, country);
            pst.setString(5, email);
            pst.execute();
            conn.close();
            return true;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public String[] searchQuestion(String title) {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            String[] arr = new String[100];
            Statement st = conn.createStatement();
            ResultSet rs;

            PreparedStatement pstmt = conn.prepareStatement("SELECT TITLE FROM ATIYA.TBL_ASKQUESTION WHERE LOWER(TITLE) like ?");
            pstmt.setString(1, ("%" + title.toLowerCase() + "%"));
            rs = pstmt.executeQuery();

            int i = 0;
            while (rs.next()) {
                arr[i] = rs.getString(1);
                i++;
            }
            conn.close();
            return arr;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public String[] searchJob (String title) {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            String[] arr = new String[100];
            Statement st = conn.createStatement();
            ResultSet rs;

            PreparedStatement pstmt = conn.prepareStatement("SELECT JTITLE FROM ATIYA.TBL_POSTJOB WHERE LOWER(JTITLE) like ?");
            pstmt.setString(1, ("%" + title.toLowerCase() + "%"));
            rs = pstmt.executeQuery();

            int i = 0;
            while (rs.next()) {
                arr[i] = rs.getString(1);
                i++;
            }
            conn.close();
            return arr;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void deletePost(String s) {
        System.out.println("stuck");
    }
    
    public void deleteJob(String s) {
        System.out.println("stuck");
    }

    public void logout() {
        landingPage obj = new landingPage();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        obj.setSize(screenSize.width, screenSize.height);

        String query = "SELECT * FROM ATIYA.LOGIN_USER";
        //make a connection with database
        Connection conn;
        Statement st;
        ResultSet rs;
        String loginEmail = "";
        try {
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            st = conn.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                loginEmail = rs.getString(1);//update LOGIN_USER set EMAIL= ? where EMAIL= ?
                query = "delete from ATIYA.LOGIN_USER ";
                PreparedStatement preparedStmt = conn.prepareStatement(query);

                preparedStmt.executeUpdate();
                break;
            }
            //rs.deleteRow();

            obj.setVisible(true);
            conn.close();

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String[] getAdminQuestions() {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            String[] arr = new String[100];
            Statement st = conn.createStatement();
            ResultSet rs;

            PreparedStatement pstmt = conn.prepareStatement("SELECT TITLE FROM ATIYA.TBL_ASKQUESTION");

            rs = pstmt.executeQuery();

            int i = 0;
            while (rs.next()) {
                arr[i] = rs.getString(1);
                i++;
            }
            conn.close();
            return arr;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }
    
    public String[] getAdminJobs() {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            String[] arr = new String[100];
            Statement st = conn.createStatement();
            ResultSet rs;

            PreparedStatement pstmt = conn.prepareStatement("SELECT JTITLE FROM ATIYA.TBL_POSTJOB");

            rs = pstmt.executeQuery();

            int i = 0;
            while (rs.next()) {
                arr[i] = rs.getString(1);
                i++;
            }
            conn.close();
            return arr;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public String[] getUserQuestions() {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            String[] arr = new String[100];
            Statement st = conn.createStatement();
            ResultSet rs;

            //which user is login
            String loginEmail = this.getLoginEmail();

            PreparedStatement pstmt = conn.prepareStatement("SELECT TITLE,EMAIL FROM ATIYA.TBL_ASKQUESTION WHERE EMAIL like ?");
            pstmt.setString(1, loginEmail);
            rs = pstmt.executeQuery();

            int i = 0;
            while (rs.next()) {

                arr[i] = rs.getString(1);
                i++;

            }
            conn.close();
            return arr;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public String[] getUserJobs() {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StackOverflow", "ATIYA", "fstky2e4mdt");
            String[] arr = new String[100];
            Statement st = conn.createStatement();
            ResultSet rs;

            //which user is login
            String loginEmail = this.getLoginEmail();

            PreparedStatement pstmt = conn.prepareStatement("SELECT JTITLE,EMAIL FROM ATIYA.TBL_POSTJOB WHERE EMAIL like ?");
            pstmt.setString(1, loginEmail);
            rs = pstmt.executeQuery();

            int i = 0;
            while (rs.next()) {

                arr[i] = rs.getString(1);
                i++;

            }
            conn.close();
            return arr;

        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
